First run the Server.py to run the server

Then login a Whatsapp account in whatsapp web default browser.

close the whatsapp web tab.

open the localhost in port 5000.

then you can login or signup. the user database is stored in userdb.txt

the passwords will be stored securely with bcrypts hashing and usage of salt during hashing.

then go to doctors section and select the relevant doctor to book appointment

then the available slots will be in your view and you can select the preferable slot and confirm booking.

confirmation page will be there and a whatsapp message will be sent to the client side using the phone number used in login/signup from the serverside whatsapp which was logged in default browser at first.

all the databases (userdb,doctordb,bookingdb,current_session,session_history) all are stored as txt files.


additional note: please use a faster pc to avoid any misfunction or untimed timeouts.
